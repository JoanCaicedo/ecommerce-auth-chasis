package com.ecommerce.back;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsCommonAuthApplicationTests {

	@Test
	void contextLoads() {
	}

}
